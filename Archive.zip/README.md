
<br>

<div align="center">
  <a href="https://github.com/tedbrakob/training-peaks-weekly-progress">
    <img src="images/icon.png" alt="Logo" width="80" height="80">
  </a>

  <h3 align="center">TrainingPeaks Weekly Progress</h3>

  <p align="center">
    <a href="https://chrome.google.com/webstore/detail/training-peaks-weekly-progress">Chrome Web Store</a>
    ·
    <a href="https://github.com/tedbrakob/training-peaks-weekly-progress">Github</a>
  </p>
</div>

<br>

Shows current weekly progress relative to planned values on TrainingPeaks calendar.

<br>

---

<div align="center">
  <img src="images/screenshot.png" alt="Logo" width="640" height="400">
</div>